
  To use this software 

0. You need to have java available on your machine.
1. unzip SRE.zip and put the files into a dedicated folder.
2. Visit the folder in a suitable command window and type the command

   java rule

3. For documentation visit http://www.math.utah.edu/~pa/sliderules/SRE.html
   That html file is also included with the software and you can view it
   offline with a suitable browser. (However, it does not have the full
   functionality of the online version.)

4. Note that after entering an expression in one of the text fields in
   the control window you need to press the enter key!

5. You can contact me at peteralfeld@gmail.com

6. The following files are included in this distribution:

   BadExpression.class, rule.class: compiled java files

   SRE.PNG: Image of SRE control panel

   table1.data, table2.data, table3.data: Tables with data for 1, 2, and 3 variable expressions.  

   scales.data: Table of scales.  Changing any of the data files will alter the performance of the software!

   runNumber: used for logging purposes

   expressions-i-.pdf pdf files with the i = 1,2,3 variable expressions

   SRE.html: html User's Guide

   README.txt: this file

